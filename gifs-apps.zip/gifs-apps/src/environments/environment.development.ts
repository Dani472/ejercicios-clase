export const environment = {
  production: false,
  companyName: 'Gifs Test',
  companyName2: 'App',
  companySlogan: 'Maneja tus gifs',

  // ApiKeys
  apiKey: 'UPcrVYQnsJU5BDHyB9f4hRFrhIQrRxJj',

  //URLS
  urlBase: 'https://api.giphy.com/v1',
};
