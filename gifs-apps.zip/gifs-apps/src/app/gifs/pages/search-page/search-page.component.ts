import { Component } from '@angular/core';

@Component({
  selector: 'app-search-page',
  imports: [],
  templateUrl: './search-page.component.html',
  styles: ``
})
export default class SearchPageComponent {

}
