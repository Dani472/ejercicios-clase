export interface Character {
  id: number;
  name: string;
  power: number;
}
